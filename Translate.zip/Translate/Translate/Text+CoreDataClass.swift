//
//  Text+CoreDataClass.swift
//  
//
//  Created by Руслан Казюка on 06.10.16.
//
//

import Foundation
import CoreData

@objc(Text)
public class Text: NSManagedObject {

}
