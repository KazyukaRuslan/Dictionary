//
//  DetailViewController.swift
//  Translate
//
//  Created by Руслан Казюка on 06.10.16.
//  Copyright © 2016 Руслан Казюка. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var translateWord: UILabel!
    @IBOutlet weak var originText: UILabel!
    
    var word: Text? {
        
        didSet{
            configureView()
        }
    }

    func configureView() {
        if word != nil {
         if let originalText = originText, let translateText = translateWord {
        originalText.text = word?.wordOriginal
        translateText.text = word?.wordTranslate
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureView()
    }
}
