//
//  CustomeCell.swift
//  Translate
//
//  Created by Руслан Казюка on 06.10.16.
//  Copyright © 2016 Руслан Казюка. All rights reserved.
//

import UIKit

class CustomeCell: UITableViewCell {

    @IBOutlet weak var OriginWord: UILabel!
    
    var word: Text? {
        
        didSet{
            configureCell()
        }
    }
    
    func configureCell(){
        
        OriginWord.text = word?.wordOriginal
    }
}
