//
//  ListWordViewController.swift
//  Translate
//
//  Created by Руслан Казюка on 06.10.16.
//  Copyright © 2016 Руслан Казюка. All rights reserved.
//

import UIKit

class ListWordViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    @IBOutlet weak var tableList: UITableView!
    
    var dict: [Text]?
    var searchResult: [Text]?
    var wors: [Word]?
    
    var searchController:UISearchController!
    var URL:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Dictionary"
        
        dict =   Text.mr_findAll() as? [Text]
        searchController = UISearchController(searchResultsController: nil);
        tableList.tableHeaderView = searchController.searchBar
        searchController.searchBar.placeholder = "Word search"
        searchController.searchBar.barTintColor = UIColor.black
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if searchController.isActive == false  {
            
               return dict!.count
            
        } else if searchResult?.count == nil {return 0} else {
            
            return searchResult!.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "Cell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath as IndexPath) as! CustomeCell
        
         cell.word = (searchController.isActive) ? searchResult?[indexPath.row]: dict?[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool{
        guard searchController.isActive else{
            return false
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!)  {
        if segue.identifier == "Showdetail"{
            
            if let indexPath = tableList.indexPathForSelectedRow {
                
                let text: Text?
            
                if searchController.isActive && searchController.searchBar.text != ""
                {
                    text =  (searchResult?[indexPath.row])!
                }
                else {text = (dict?[indexPath.row])!}
                
                let wordDetailVC = segue.destination as! DetailViewController
                wordDetailVC.word = text
            }
        }
    }
}

extension ListWordViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        
        let searchText: String!
        searchText = searchController.searchBar.text
        let text =  searchController.searchBar.textInputMode
        
        Api.sharedInstance.getTranslateText(text: text!, searchText: searchText, completion: { (words) in
           
            self.searchController.isActive = false
            self.dict?.append(contentsOf: words)
            self.tableList.reloadData()
            
            }) { (error) in
        }
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
    }
}

extension ListWordViewController: UISearchResultsUpdating {
    @available(iOS 8.0, *)
    public func updateSearchResults(for searchController: UISearchController) {
      
        if let searchText = searchController.searchBar.text
        {
            filterContent(searchText: searchText)
            tableList.reloadData()
        }
    }
    func filterContent(searchText:String){
        
        searchResult = dict?.filter({ (word:Text!) -> Bool in
            
          
            let name =  word.wordOriginal?.range(of: searchText, options: NSString.CompareOptions.caseInsensitive, range: nil, locale: nil)
    
            return name != nil
        })
        
        tableList.reloadData()
    }
}
