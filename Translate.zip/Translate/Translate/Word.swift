//
//  Word.swift
//  Translate
//
//  Created by Руслан Казюка on 06.10.16.
//  Copyright © 2016 Руслан Казюка. All rights reserved.
//

import Foundation

class  Word {
    
    var originWord: String?
    var translateWord: String?
    
    init(initWithDictionary: NSDictionary) {
        
       originWord =  initWithDictionary["segment"] as? String
       translateWord = initWithDictionary["translation"] as? String
    }
    
    class func getWord(_ words:NSDictionary) -> [Text] {
        
        var wordsArray = [Text]()
        let dictionary = words["matches"] as! [NSDictionary]
        
        for word in dictionary {
            
             let translateWords = Word(initWithDictionary: word)
            
            let textEntity =  Text.mr_createEntity() as! Text
            textEntity.wordTranslate = translateWords.translateWord
            textEntity.wordOriginal = translateWords.originWord
            NSManagedObjectContext.mr_default().mr_saveToPersistentStoreAndWait()
            
            wordsArray.append(textEntity)
        }
       
        return wordsArray
    }
}
