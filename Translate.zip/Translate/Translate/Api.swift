//
//  Api.swift
//  Translate
//
//  Created by Руслан Казюка on 06.10.16.
//  Copyright © 2016 Руслан Казюка. All rights reserved.
//

import UIKit
import Alamofire

class Api {
    
    static let sharedInstance = Api()
    
    var URL: String!
    
    func getTranslateText( text: UITextInputMode, searchText: String, completion: @escaping ([Text]) -> (),  error:@escaping (NSError)->() ){
        
        let Language =  text.primaryLanguage;
        
        if Language == "ru-RU" {
            URL = "http://api.mymemory.translated.net/get?q=\(searchText)&langpair=ru|en"
        }
        else {
            URL = "http://api.mymemory.translated.net/get?q=\(searchText)&langpair=en|ru"
        }
        let urlStr = URL.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed)

        Alamofire.request(urlStr!, method: .get ).validate().responseJSON { response in
            switch response.result {
            case .success:
                
                let dictionary = try! JSONSerialization.jsonObject(with: response.data!, options: []) as! NSDictionary
               
                
                let word = Word.getWord(dictionary)
                
                completion(word)
                
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
