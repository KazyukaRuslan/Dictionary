//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#ifndef Dict_Dict_Bridging_Header_h
#define Dict_Dict_Bridging_Header_h
#define MR_SHORTHAND
#import <MagicalRecord/CoreData+MagicalRecord.h>

#endif
