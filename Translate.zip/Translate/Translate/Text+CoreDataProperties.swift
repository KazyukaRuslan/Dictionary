//
//  Text+CoreDataProperties.swift
//  
//
//  Created by Руслан Казюка on 06.10.16.
//
//

import Foundation
import CoreData


extension Text {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Text> {
        return NSFetchRequest<Text>(entityName: "Text");
    }

    @NSManaged public var wordOriginal: String?
    @NSManaged public var wordTranslate: String?

}
